"$1"/bin/asadmin start-domain
"$1"/bin/asadmin deploy --force AppBank/dist/AppBank.ear
